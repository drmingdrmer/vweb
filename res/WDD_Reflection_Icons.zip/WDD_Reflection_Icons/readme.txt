
----------------------------------------
Reflection Icon Set by Webdesigner Depot
http://www.webdesignerdepot.com
----------------------------------------

TERMS OF USE:

This product may be used free of charge for personal and/or commercial purposes.

These icons are licensed as 'linkware', which means that you need to link to www.webdesignerdepot.com wherever you use them online (or print the url when using them for offline purposes). If you do not want to use them with attribution, there's a one time $20 fee to purchase the set and remove this requirement, payable via Paypal to info@webdesignerdepot.com

You may not modify, sell or distribute this file on any website, CD-ROM or by any other means whatsoever (including electronic and print distribution), without written consent from Webdesigner Depot. 

If you'd like to share this file with others, please direct them to our website where they can download their copy.

Thanks for supporting our website and enjoy!


Webdesigner Depot
_________________________
www.webdesignerdepot.com
info@webdesignerdepot.com
