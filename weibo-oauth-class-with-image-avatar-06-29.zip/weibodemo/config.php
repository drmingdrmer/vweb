<?php
define( "WB_AKEY" , '请填入微博开放平台的APP Key' );
define( "WB_SKEY" , '请填入微博开放平台的APP Secret' );

?>